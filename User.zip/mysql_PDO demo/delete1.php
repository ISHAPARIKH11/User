<a href="logout.php" > Logout  </a> <br> <br>
<?php
require_once 'mainclass.php';
$obj = new mainclass();
 
 if(!isset($_SESSION['admin']))   
 {
     header('location:index.php');
 }

 $r = $obj->deleteuser($_GET['username']);
 
 if($r)
 {
     header("location:admin.php");
 }
 
?>
