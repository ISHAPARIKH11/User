<a href="logout.php" > Logout  </a> <br> <br>
<?php
require_once 'mainclass.php';
if(!isset($_SESSION['username']))
{
    header('location:login.php');
}
 else {
    
    $obj = new mainclass();
    $r = $obj->fetchuserprofile($_SESSION['username']);
  //  print_r($r);
     foreach($r as $v){
     $event = explode(',', $v[4]);
   //  print_r($event);
    
     ?>
<form>
   Username:- <input type="text" name="uname" value="<?php echo $v[1]; ?>" > <br>    
    Password:- <input type="text" name="password" value="<?php echo $v[2]; ?>"> <br>    
    ContactNo:- <input type="text" name="contactno" value="<?php echo $v[3]; ?>"> <br>  
    <hr> Event Details </hr>
    C <input type="checkbox" name="event[]" value="c" <?php foreach($event as $e) if($e == 'c') echo "checked"; ?> >
    C++ <input type="checkbox" name="event[]" value="c++" <?php foreach($event as $e) if($e == 'c++') echo "checked"; ?>>
     PHP <input type="checkbox" name="event[]" value="php" <?php foreach($event as $e) if($e == 'php') echo "checked"; ?> >
      Java <input type="checkbox" name="event[]" value="java" <?php foreach($event as $e) if($e == 'java') echo "checked"; ?> >
    <input type="submit" name="submit" value="Update" > <br>     
   </form>

     <?php  }
     
 }
?>

<?php
if(isset($_REQUEST['submit']))
{
     require_once 'mainclass.php';
    $obj = new mainclass();
    $event = implode(',', $_REQUEST['event']);
    $f = $obj->updateuserprofile($_REQUEST['password'], $_REQUEST['contactno'],$event,$_SESSION['username'] );
    if($f == 1)
    {
        header('location:profile.php');
   }
    else
        echo "update not done";
    
}

?>