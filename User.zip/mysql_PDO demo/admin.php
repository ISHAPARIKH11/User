<a href="logout.php" > Logout  </a> <br> <br>
<?php
 //session_start();
 require_once 'mainclass.php';
 
 if(!isset($_SESSION['admin']))   
 {
     header('location:index.php');
 }
 
 //print_r($rs);
?>
<form>
    Enter Username:- <input type="text" name="uname" > 
    <input type="submit" name="submit" value="search" >
           
</form>

<?php
 
if(isset($_REQUEST['submit']))
{
    require_once 'mainclass.php';
    $obj = new mainclass();
    if($_REQUEST['uname'] == "")
        $rs = $obj->fetchusers();
    else
        $rs = $obj->fetchuserprofile($_REQUEST['uname']);
}
else
{
    $obj = new mainclass();
    $rs = $obj->fetchusers();
}
 
 echo "<table border=1><tr>";
 echo "<th>Username </th><th> Password </th><th> Contact Number </th><th> Events </th> </tr>";
 foreach($rs as $v){
     echo "<td>".$v[1] . "<td>". $v[2]."<td>". $v[3]. "<td>". $v[4];
     echo "<td> <a href=update1.php?username=" . $v[1] . " > update  </a>";
      echo " <td> <a href=delete1.php?username=" . $v[1] . " > delete  </a>";
     echo "</tr>";
 }

echo "</table>";
?>

