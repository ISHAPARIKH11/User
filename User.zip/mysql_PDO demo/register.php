<a href="logout.php" > Logout  </a> <br> <br>
<form method="post" action="#" >
    Username:- <input type="text" name="uname" > <br>    
    Password:- <input type="text" name="password" > <br>    
    ContactNo:- <input type="text" name="contactno" > <br>  
    <hr> Event Details </hr>
    C <input type="checkbox" name="event[]" value="c" >
    C++ <input type="checkbox" name="event[]" value="c++" >
     PHP <input type="checkbox" name="event[]" value="php" >
      Java <input type="checkbox" name="event[]" value="java" >
    <input type="submit" name="submit" value="Register" > <br>    
</form>

<?php
if(isset($_REQUEST['submit']))
{
    require_once "mainclass.php";
    $obj = new mainclass();
    $r = $obj->fetchuserprofile($_REQUEST['uname']);
 //   print_r($r);
 //   echo count($r);
    if(count($r) == 0)
    {
    
        
    $event = implode(',', $_REQUEST['event']);
   // echo $event;
    $f = $obj->insertprofiledata($_REQUEST['uname'], $_REQUEST['password'], $_REQUEST['contactno'], $event);
    if($f)
       header('location:login.php'); 
    
    }
    else{
        echo "username already exist";
    die(); }
 


}

?>