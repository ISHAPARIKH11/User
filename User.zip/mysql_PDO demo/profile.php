<a href="logout.php" > Logout  </a> <br> <br>
<?php
require_once "mainclass.php";
if(!isset($_SESSION['username']))
{
    header('location:login.php');
}
 else {
    echo "Welcome :- " . $_SESSION['username'] . "<br>";
 
 
 $obj = new mainclass();
 
 $r = $obj->fetchuserprofile($_SESSION['username']);
 //print_r($r);
 
echo "<table border=1>";
echo "<tr> <th> Username <th> Password <th> Contact Number <th> Events </tr>";
foreach($r as $v)     
{
    
    echo "<tr><td>" . $v[1] . "</td>" . "<td>" . $v[2]   . "</td>"  . "<td>" . $v[3]   . "</td>" . "<td>" . $v[4]   . "</td>";     
    echo "</tr>";
}
  echo "<a href=update.php > update </a>"; 
 
 }

?>
