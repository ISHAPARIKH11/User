<?php
session_start();
class mainclass
{
    private $con;
    
    function __construct() 
    {
        $this->con = new PDO('mysql:host=localhost;dbname=test123','root','');
        $this->con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            
    }
    function deleteuser($a)   
    {
        $qry = "delete from profile where username=:a ";
      
        $stmt = $this->con->prepare($qry);
        $stmt->bindParam(':a',$a );
          
        $f = $stmt->execute();
             
        return $f;
    }
    
    function insertprofiledata($a, $b, $c, $d)
    {
               
    
        $qry = "insert into profile(username, password, contactno, event) values(:a, :b, :c, :d);";
        try{ 
        $stmt = $this->con->prepare($qry);
        }
        catch (PDOException $e){
        echo $e->getMessage();
        }
        
        $stmt->bindParam(':a',$a );
        $stmt->bindParam(':b',$b );
        $stmt->bindParam(':c',$c );
         $stmt->bindParam(':d',$d );
        try{
        $f = $stmt->execute();
        }
        catch (PDOException $e){
        echo $e->getMessage();
        }
        
        return $f;
       // }
    }
    function validateuser($a,$b)
    {
         $qry = "select * from profile where username=:a and password=:b";
         $stmt = $this->con->prepare($qry);
         $stmt->bindParam(':a', $a);
         $stmt->bindParam(':b', $b);
         try
         {
             $rs = $stmt->execute();
         } catch (PDOException $ex) {
             $ex->getMessage();
         }
         
         if($a == 'admin' and $b == 'admin')
         {  
                       
             $_SESSION['admin'] = 'admin'; 
             header('location:admin.php');
                                
         }
         else
         {
                   
         $f = $stmt->rowCount();
         return $f;
         
         }
    }
    
   
   function fetchuserprofile($a)
   {
       $q = "select * from profile where username=:a";
       $stmt = $this->con->prepare($q);
       $stmt->bindParam(':a', $a);
       try{
           $stmt->setFetchMode(PDO::FETCH_NUM);
           $stmt->execute();
           $r = $stmt->fetchall();
            //  print_r($r);
           
       } catch (PDOException $ex) {
           echo $ex->getMessage();
       }
       
       return $r;
   }
    
   function fetchusers()
   {
       $q = "select * from profile";
       $stmt = $this->con->prepare($q);
       
       try{
           $stmt->setFetchMode(PDO::FETCH_NUM);
           $stmt->execute();
           $r = $stmt->fetchall();
            //  print_r($r);
           
       } catch (PDOException $ex) {
           echo $ex->getMessage();
       }
       
       return $r;
   }
    
   
   
   
   
   function updateuserprofile($a, $b, $c, $d)
   {
       $q = "update profile set password=:a, contactno=:b, event=:c where username=:d";
       $stmt = $this->con->prepare($q);
       $stmt->bindParam(':a', $a);
       $stmt->bindParam(':b', $b);
       $stmt->bindParam(':c', $c);
       $stmt->bindParam(':d', $d);
       try
       {
          $f = $stmt->execute();
       } catch (PDOException $ex) {
            echo $ex->getMessage();
       }
     
       return $f;
   }
    
}
?>