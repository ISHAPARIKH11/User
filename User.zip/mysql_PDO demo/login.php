<form method="get" action="#" >
    Username:- <input type="text" name="uname" > <br>    
    Password:- <input type="text" name="password" > <br>    
    
    <input type="submit" name="submit" value="Login" > <br>    
</form>
<?php
session_start();
if(isset($_REQUEST['submit']))
{
    require_once "mainclass.php";
    $obj = new mainclass();
    
    $flag = $obj->validateuser($_REQUEST['uname'], $_REQUEST['password']);
    if($flag)
    {
       $_SESSION['username'] = $_REQUEST['uname'];
        header('location:profile.php');
     }
    else
        echo "try again";
}
?>
